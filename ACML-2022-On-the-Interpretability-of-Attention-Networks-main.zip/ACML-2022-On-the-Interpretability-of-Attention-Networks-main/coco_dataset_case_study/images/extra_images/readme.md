some extra images and plots from case study
