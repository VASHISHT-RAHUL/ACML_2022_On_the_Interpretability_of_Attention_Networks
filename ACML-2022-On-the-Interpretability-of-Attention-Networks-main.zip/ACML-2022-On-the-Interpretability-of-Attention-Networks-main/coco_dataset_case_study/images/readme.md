# Images used in paper for coco case study section
