Prediction files for COCO case study
