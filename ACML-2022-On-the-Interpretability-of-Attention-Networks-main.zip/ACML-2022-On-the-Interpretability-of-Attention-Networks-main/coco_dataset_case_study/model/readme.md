Architecture of the model used for the COCO case study
