## COCO Dataset
This repo contains all the code files (python notebook) used for the case study.
