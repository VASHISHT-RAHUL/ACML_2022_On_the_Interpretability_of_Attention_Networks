saved dictionaries, word association used for class labels and script for generating dictionaries
