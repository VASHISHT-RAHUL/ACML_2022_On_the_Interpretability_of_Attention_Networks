Codes used for Synthetic Dataset SDC and CIFAR Dataset SDC task.
